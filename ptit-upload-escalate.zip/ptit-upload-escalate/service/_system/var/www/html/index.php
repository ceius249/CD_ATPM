<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
</head>
<body>
    <h1>File Upload</h1>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["file"])) {
        $uploadDir = 'assets/';
        $uploadFile = $uploadDir . basename($_FILES['file']['name']);
        $uploadedFilePath = 'http://localhost/' . $uploadFile;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
            echo '<p>File has been uploaded successfully.</p>';
            echo '<p>File URL: <a href="' . $uploadedFilePath . '">' . $uploadedFilePath . '</a></p>';		
	    chmod($uploadFile, 0755);
        } else {
            echo '<p>Sorry, there was an error uploading your file.</p>';
        }
    }
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <label for="file">Choose a file to upload:</label>
        <input type="file" name="file" id="file" required>
        <br>
        <input type="submit" value="Upload File">
    </form>
</body>
</html>

