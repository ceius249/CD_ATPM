#!/bin/bash

# exiftool 
	# encode
base64 /home/$USER/passphr > /home/$USER/encoded

	# add comment to cat.jpeg
cat /home/$USER/encoded | exiftool /home/$USER/cat.jpeg -Comment=$(cat)

# steghide

cat /home/$USER/encoded | steghide embed -p $(cat) -cf /home/$USER/cat.jpeg -ef /home/$USER/flag.txt -v

rm /home/$USER/passphr /home/$USER/encoded /home/$USER/flag.txt
