#!/bin/bash

# setup variable
USER_DIR="/home/$USER"
PASSPHR_FILE="$USER_DIR/passphr"
ENCODED_FILE="$USER_DIR/encoded"
CAT_IMG="$USER_DIR/cat_image.jpeg"
FLAG_FILE="$USER_DIR/flag"

# exiftool
## encode
base64 "$PASSPHR_FILE" > "$ENCODED_FILE"

## add comment to cat_image.jpeg
exiftool "$CAT_IMG" -comment="$(cat "$ENCODED_FILE")" -preserve -overwrite_original -m -q -q

