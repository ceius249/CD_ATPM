#!/bin/bash

# set up variable
USER_DIR="/home/$USER"
PASSPHR_FILE="$USER_DIR/passphr"
ENCODED_FILE="$USER_DIR/encoded"
CAT_IMG="$USER_DIR/cat_image.jpeg"
FLAG_FILE="$USER_DIR/flag.txt"

# set up labs (temps)
# echo "hello" > "$PASSPHR_FILE"
# echo "thisisflag" > "$FLAG_FILE"

# steghide
## passphrase $ENCODED_FILE
## coverfile $CAT_IMG
## embedfile $FLAG_FILE
steghide embed -p "$(cat "$ENCODED_FILE")" -cf "$CAT_IMG" -ef "$FLAG_FILE"

# remove not-essential files
rm $PASSPHR_FILE $ENCODED_FILE $FLAG_FILE