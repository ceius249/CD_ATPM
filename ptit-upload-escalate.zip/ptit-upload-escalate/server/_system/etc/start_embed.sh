#!/bin/bash

/etc/comment_passphrase.sh
/etc/embed_flag.sh

